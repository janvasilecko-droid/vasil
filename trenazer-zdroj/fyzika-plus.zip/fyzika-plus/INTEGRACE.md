# FYZIKA+ – jak úpravu vložit do novější verze trenažéru

Balíček je udělaný tak, aby šel vložit do **jiné (novější) verze**, než na které vznikl (2D v70 / 3D v152).
Všechno počítání je v novém souboru `fyzika_plus.gd`. Do stávajících skriptů se vkládají jen krátké „háčky“
(1–3 řádky), které se hledají **podle textu**, ne podle čísel řádků.

## 1. Automaticky (doporučeno)

Potřebuješ Python 3.8 nebo novější, žádné další knihovny.

```
python aplikuj_fyzika_plus.py "D:\stazene\Trenazer-varny-aplikace" --zkouska   ← jen vypíše, co by udělal
python aplikuj_fyzika_plus.py "D:\stazene\Trenazer-varny-aplikace"             ← vloží
```

Cesta je složka projektu, kde leží `project.godot` a `sim.gd`. Když zadáš nadřazenou složku, skript `sim.gd` najde sám.
Pro 3D verzi spusť skript ještě jednou se složkou 3D projektu, protože obě verze mají vlastní kopii skriptů.

Co skript dělá:
- zkopíruje `fyzika_plus.gd` a `fyzika_plus_tests.gd` do projektu;
- vloží háčky H0–H9, U1–U2 a R1 (tabulka níže). **Háček, jehož místo nenajde přesně jednou, přeskočí a napíše proč.**
  Skupina úprav, která spolu souvisí, se vloží buď celá, nebo vůbec. Nic se tedy nerozbije napůl;
- před první změnou si každý soubor zazálohuje jako `<soubor>.pred-fyzika-plus`;
- zapíše `fyzika_plus_hooks.gd` se seznamem vložených háčků. Testy podle něj přeskočí, co chybí;
- jde spustit znovu: už vložené háčky pozná a podruhé je nevloží.

Ověření po vložení (Godot 4.3 pro 2D, Godot 4.7 pro 3D):
```
Godot --headless --path "<projekt>" -- --tests       ← všechny testy včetně 36 nových „FP …“
Godot --headless --path "<projekt>" -- --autotest    ← celá automatická várka
```
Testy nespouštěj souběžně ve dvou kopiích projektu: mají stejný název, sdílejí `user://` (uložení várky)
a test „uložení: várka se načte“ pak náhodně selže.

**Vrácení:** přejmenuj `*.pred-fyzika-plus` zpět na původní názvy a smaž `fyzika_plus.gd`, `fyzika_plus_tests.gd`
a `fyzika_plus_hooks.gd`.

**Nastavení bez úprav kódu:** všechny nové parametry jdou přepsat v `kalibrace.json` jako ostatní, např.
`{"stValveR": 1.0, "rvpKvs": 40.0, "jVacBreaker": 0}`.

Hlavní nové parametry a výchozí hodnoty (celý seznam se zdroji je ve `fyzika_plus.gd`, konstanty `DEF` a `RANGE`):

| Parametr | Výchozí | Význam |
|---|---|---|
| `stValveR` | 30 (ODHAD) | charakteristika parního ventilu: 1 = lineární (ruční), 30–50 = ekviprocentní (regulační) |
| `rvpKvs`, `mpKvs` | 0 | Kvs parního ventilu pánve; 0 = dopočítat (plně otevřený ventil při 60 °C ubere 10 % tlaku) |
| `stCondBack` | 0,15 bar (ODHAD) | protitlak kondenzátu; pod ním kondenzát z pláště neodtéká (stall) |
| `jDrainKgS` | 0,6 kg/s (ODHAD) | kapacita odvaděče kondenzátu (plná od rozdílu tlaků 0,5 bar) |
| `jVacBreaker` | 1 | plášť má zavzdušňovací ventil (0 = nemá, po zavření páry podtlak) |
| `hNatC` | 0,28 | přestup bez míchadla (přirozená konvekce) vůči míchané referenci |
| `colK100`, `colEa`, `colPh` | 1,2 EBC/h; 77 kJ/mol; 0,7 | tvorba barvy při 100 °C, pH 5,5 a 12 °P |
| `phBoilDrop`, `phSparge`, `wortBuf` | 0,08/h; 0,05; 26,6 | pokles pH za varu, sladina proti rmutu, pufr mladiny |
| `wpInletMM` | 0 | průměr nátokového hrdla vířivky; 0 = jako trubka v plánku |
| `wpVmax`, `wpVmin` | 3,5 m/s; 1,0 m/s (ODHAD) | nad tím se lom tříští; pod tím se vířivka roztáčí slabě |
| `pipeU` | 10 W/(m²·K) | ztráty holé trubky do okolí |

## 2. Háčky – co, kam a proč (pro ruční vložení nebo pro Clauda doma)

Odsazení: sim.gd v70 používá 4 mezery. Pokud tvoje verze používá tabulátory, skript to převede sám.
Při ručním vkládání drž odsazení okolních řádků.

| Háček | Soubor | Najdi | Udělej |
|---|---|---|---|
| **H0** | sim.gd | `const Physics = preload("res://physics.gd")` (případně `extends RefCounted`) | Pod něj přidej řádek `const FP = preload("res://fyzika_plus.gd")` |
| **H1** | sim.gd | hlavičku `func _pd(v, UA: float, jL: float, Tst: float) -> Dictionary:` | Hned pod ni jako první řádek těla dej `return FP.steam_pd(self, v, UA, jL, Tst)`. Starý kód pod ním už neproběhne (Godot jen upozorní na nedosažitelný kód) |
| H1 (2. část) | sim.gd | v `sim_step()`: `S._pd.rvp.P *= film_factor(rvp);S._pd.mp.P *= film_factor(mp)`; ve starších verzích v `heat()` řádek `Pin *= ff` | **Zakomentuj** (`#`). Film už je ve `FP.steam_pd`, jinak by se započítal dvakrát. **Bez této části H1 nevkládej** |
| **H2** | sim.gd | hlavičku `func film_hA(v) -> float:` | Jako první řádek těla dej `return FP.film_hA(self, v)` |
| **H3a** | sim.gd | v `react()`: `var ph_d: float = clampf(float(S.get("pH", 5.5)), 5.0, 5.8)` | Nahraď `float(S.get("pH", 5.5))` za `FP.vessel_ph(self, v)` |
| **H3b** | sim.gd | v `react()` řádek s `isoPh` a `S.get("pH", 5.5)` | Nahraď `float(S.get("pH", 5.5))` za `FP.vessel_ph(self, v)`. Když verze ještě nemá `isoPh`, místo toho na konec řádku `var k1 = 790000000000.0 * exp(-11858.0 / TK)` přidej ` * FP.iso_ph_factor(self, v)` |
| **H4** | sim.gd | začátek `react()`: `func react(v, m: float) -> void :` a pod ním `if v.w < 1: return` | Pod `if v.w < 1: return` přidej `FP.color_step(self, v, m)` |
| H4 (2. část) | sim.gd | v bloku varu `v.col += liqVol(v) * 2.5 / 60.0 * m` | Nahraď za `FP.boil_step(self, v, m)` (pevný přírůstek barvy zmizí, barvu počítá color_step). **Obě části H4 jen spolu** |
| **H5** | sim.gd | v `dstGive()` u „wp“: `S.wp.whirlMin += ctx.get("m", 0.0)` | Změň na `S.wp.whirlMin += ctx.get("m", 0.0) * FP.whirl_inlet(self, S.wp, p, ctx)` |
| H5 (2. část) | sim.gd | v usazování kalu: `var fl: float = 0.1 * v.trubHB` | Změň na `var fl: float = minf(v.trubSus, 0.1 * v.trubHB + FP.trub_ns(self, v))`. **Obě části H5 jen spolu** |
| **H6** | sim.gd | v `net_step()`: `e.c.T += (c.ambientT - e.c.T) * kcool` a `for b in e.q: b.T += (c.ambientT - b.T) * kcool` | První řádek změň na `var kc_fp: float = FP.pipe_cool_k(self, e, dt); e.c.T += (c.ambientT - e.c.T) * kc_fp`, ve druhém nahraď `kcool` za `kc_fp` |
| **H7** | sim.gd | `func hotV(v)…: return liqVol(v) * (1.0 + 0.00052 * maxf(0.0, v.T - 20.0))` | Změň na `return liqVol(v) * FP.expansion(v.T)` |
| H7b | sim.gd | v `density()`: `var exp_f: float = 1.0 + 0.00052 * maxf(0.0, v.T - 20.0)` | Změň na `var exp_f: float = FP.expansion(v.T)` |
| **H8** | sim.gd | `const CFG_DEFAULT: = {` a `const CALIB_RANGE: = {` | Hned za otevírací závorku vlož nové klíče s výchozími hodnotami a rozsahy (seznam je ve `fyzika_plus.gd`, konstanty `DEF` a `RANGE`). Klíče, které už v souboru jsou (např. `isoPh`), přeskoč |
| H8p | params.gd | `const META: = {` | Popisy nových parametrů (zdroj, nejistota), aby byly v PARAMETRY.md |
| **H9** | tests.gd | `var AU = preload("res://audit_tests.gd").new();AU.run(self)` | Pod něj přidej `var FPT = preload("res://fyzika_plus_tests.gd").new();FPT.run(self)` |
| H9f | tests.gd | referenční test přestupu tepla: `var thin = sim.vessel(); thin.w = 2000.0; thin.stir = true; thin.hz = 35.0` | Doplň `;thin.T = 60.0`. Referenční přestup teď platí pro vodu 60 °C, protože nově závisí na teplotě |
| H9g | audit_tests.gd | `var w = sim.vessel(); w.w = 2000.0; w.stir = true; w.hz = 35.0` | Doplň `; w.T = 60.0` (stejný důvod) |
| H9h | audit_tests.gd | `var vh1 = _mkv(100.0); vh1.alpha = 100.0…` (referenční test izomerace) | Nad řádek dej `sim.S["pH"] = 5.5` (v70 to už má). Při pH 5,5 je korekce izomerace neutrální, takže referenční hodnota testu platí dál |
| U1 | ctl.gd | `refs.hop = _btn(r, "", func(): m.sim.hopPlanAdd();refresh())` + v `refresh()` řádek `else: _t(refs.hop, "Chmel podle receptu přidán…` | Tlačítko „Kyselina mléčná 80 % do mladiny +100 mL (pH …)“ a jeho popisek |
| U2 | ctl.gd | `_t(refs.boiler, "Pára z kotle: …")` | Za text přidej `+ preload("res://fyzika_plus.gd").jacket_label(m.sim)`. Zobrazí tlak v plášti pánve, zaplavení kondenzátem a vzduch |
| R1 | sim.gd | `S.boiler.load = Qb / c.boilerKW` a `rep.merge(yields())` | Pod první dej `FP.energy_step(self, Qb, dt)`, pod druhý `FP.report_extra(self, rep)`. Protokol pak ukáže kWh páry na hl, pH mladiny a odhad barvy piva |

Závislosti: H1–H7, U1, R1 potřebují H0. U2 potřebuje H1, H9f a H9g potřebují H2, H9h potřebuje H3b.
Na ostatních háčcích nic nezávisí.

## 3. Pro Clauda doma (zadání)

> V projektu trenažéru varny (Godot) vlož balíček FYZIKA+ ze složky `fyzika-plus`.
> 1. Spusť `python aplikuj_fyzika_plus.py "<složka projektu>" --zkouska` a přečti si zprávu.
> 2. Když hlásí jen přeskočené volitelné háčky (·), spusť skript bez `--zkouska`.
>    Když hlásí přeskočený hlavní háček (✗), otevři INTEGRACE.md, najdi v sim.gd místo s tou funkcí podle smyslu
>    (verze se mohla změnit) a háček vlož ručně. Pak skript spusť znovu, aby zapsal `fyzika_plus_hooks.gd`.
> 3. Spusť testy (`-- --tests`) a automatickou várku (`-- --autotest`). Porovnej protokol s tabulkou
>    „Ověření“ ve FYZIKA_PLUS.md: objem, °P, IBU, EBC, DMS mají vyjít podobně (EBC ve spilce o ~1,5 výš, pára ~21 kWh/hl).
> 4. Nic jiného neměň. Pravidla projektu: žádná vymyšlená čísla (odhad označit ODHAD), nesahat na trasy,
>    klapky a polohy čerpadel ani na plán editoru. Text z knih Kosa a Kunze se do repozitáře nedává, jen čísla
>    s odkazem na stranu.
