# FYZIKA+ pro trenažér varny – obsah balíčku

| Soubor | Co to je |
|---|---|
| `FYZIKA_PLUS.md` | **Hlavní dokument:** co jsem v programu našel, reálná data z jiných varen a z literatury (se zdroji), co úprava mění, návrhy na další kroky, co změřit na Zajíci, výsledky ověření |
| `INTEGRACE.md` | Jak úpravu vložit do novější verze: automaticky skriptem, nebo ručně podle tabulky háčků (i zadání pro Clauda doma) |
| `aplikuj_fyzika_plus.py` | Skript, který úpravu vloží: `python aplikuj_fyzika_plus.py "<složka projektu>"` (napřed s `--zkouska`) |
| `fyzika_plus.gd` | Nový modul s veškerým počítáním (pára a plášť, přestup tepla, pH, barva, vířivka, trubky, objem) |
| `fyzika_plus_tests.gd` | 36 nových automatických kontrol (spustí se s `-- --tests`) |
| `reference-v70/` | Pro kontrolu: soubory v70 po vložení úpravy a rozdíl `zmeny-v70.diff` proti původní v70 |

Nejrychlejší cesta: rozbal složku, spusť `python aplikuj_fyzika_plus.py "D:\stazene\Trenazer-varny-aplikace" --zkouska`,
přečti si zprávu, pak to samé bez `--zkouska`. Nakonec spusť testy a automatickou várku.
