# FYZIKA+: realističtější fyzika a chemie trenažéru varny

Vypracováno 29. 10. 2026 na zdrojích 2D v70 / 3D v152 (`vasil/unity/GodotSrc`). Balíček je stavěný tak, aby šel vložit
i do novější verze (viz INTEGRACE.md). **Nic z toho není vydané** v ⟳ Aktualizovat ani nahrané do sdíleného zdroje.
Vzorce, jednotky a vkládací skript prošla ještě nezávislá kontrola, její připomínky jsou zapracované.

> Upřímně: všechna čísla jsou z literatury nebo z jiných varen, ne z měření na Zajíci. Kde údaj chybí, je hodnota
> označená ODHAD a jde přepsat v `kalibrace.json`. Seznam věcí k naměření je v kapitole 5.

---

## 1. Co jsem v programu prošel a co jsem našel

Prošel jsem `sim.gd` (teplo, pára, var, reakce, potrubí, čerpadla, scezování, vířivka, chlazení), `proc.gd`
(pH, kvašení, CIP), `physics.gd`, `auto.gd`, testy a starší audity (22. 10.). Většina fyziky je v pořádku:
bilance energie a extraktu, ε-NTU chladiče, Darcy u lože, čerpadlo × odpor trasy, Malowicki a Dickenson.
Zbyla tahle slabá místa:

| # | Oblast | Co bylo | Proč to není reálné | Stav |
|---|---|---|---|---|
| 1 | **Pára** | výkon = UA × % ventilu × (T_páry − T) | Ventil neškrtí plochu, škrtí **průtok páry**. Tlak v plášti se ustaví podle rovnováhy ventil ↔ kondenzace. Při přiškrcení tlak v plášti spadne, u chladné náplně až k podtlaku, a kondenzát neodtéká („stall“). Na tohle upozorňoval už audit z 22. 10. | **opraveno (H1)** |
| 2 | **Přestup na straně náplně** | nemíchaná náplň = míchadlo na „4 Hz“; přestup nezávisel na teplotě | Řídká mladina se bez míchadla ohřívá přirozenou konvekcí, hustý rmut skoro vůbec, a proto se připaluje. Viskozita vody je při 20 °C 3,6× větší než při 100 °C, takže studená náplň předává hůř | **opraveno (H2)** |
| 3 | **pH** | jedno pH (rmutu) pro všechno, i pro vroucí mladinu | Za varu pH klesá (VLB 5,62 → 5,50 za 90 min), a izomerace chmele i SMM → DMS braly pH rmutu. Můj dřívější pokus s okyselením nemohl fungovat, protože `proc.step()` každý krok přepisuje `S.pH` | **opraveno (H3, H4)** |
| 4 | **Barva** | +2,5 EBC/h jen za varu, nezávisle na čemkoli | Maillardova reakce závisí na teplotě (Ea 77 kJ/mol), pH a extraktu. Barva přibývá i při **dekokci**, ve **vířivce** a během chlazení (VLB: vyražená 11,3 → 13,6 EBC, než se zchladí polovina) | **opraveno (H4)** |
| 5 | **Vířivka** | rychlost nátoku neměla vliv | Kunze: nátok max. 3,5 m/s, jinak se lom tříští; slabý nátok vířivku neroztočí | **doplněno (H5)** |
| 6 | **Trubky** | stojící obsah všech trubek chladl s τ = 30 min | Plná trubka DN50 z plánku (vnitřní průměr podle kalibrace `bore50` 75 mm) má podle konvekce, oceli a vody τ ≈ 2,3 h; tenčí trubky chladnou rychleji | **opraveno (H6)** |
| 7 | **Objem horké vody** | lineárně 0,00052/K | Při 100 °C to sedí (4,16 %), při 50 °C je to o 0,5 % víc (20 L na 40 hl) | **opraveno (H7, Kell 1975)** |
| 8 | Kyselina mléčná do rmutu | `11,8 mEq/mL` u „80 %“ | 11,8 platí pro 88% kyselinu, 80% má ~10,6 mEq/mL | jen upozornění, neměnil jsem |
| 9 | `film_factor()` | počítá vždy s `rvpUAst`, i pro mladinovou pánev | drobná chyba (MP v plánku nepoužitá) | FP.steam_pd bere správné UA |
| 10 | Připalování v `heat()` | výkon nádobě ubere 10 %, ale kotel už vyrobil 100 % | při připalování nesedí bilance energie (10 % zmizí) | jen upozornění |
| 11 | Testy | `%g` ve formátovacím řetězci | Godot `%g` nezná → 2× „unsupported format character“ v logu | jen kosmetika |
| 12 | Výchozí voda | alkalita 100 mg/L → pH rmutu 5,84 | O 0,2–0,3 víc než obvykle (Kosa s. 136: rmut 5,5–5,6; Kunze s. 286: sladina 5,5–5,6) → víc barvy, rychlejší DMS a izomerace | zadej rozbor vody v panelu |
| 13 | Ledová voda | čerpadlo ledové vody pevně 120 L/min | Kunze: ledová voda 1–2 °C se v chladiči ohřeje na 80–88 °C. To jde jen se seřízeným poměrem vody k mladině (~1,05–1,1 : 1) | návrh N1 |

---

## 2. Reálná data z jiných varen a z literatury

| Veličina | Hodnota | Zdroj | Jak je to v modelu |
|---|---|---|---|
| Průtok syté páry ventilem | ṁ = 12·Kv·P1·√(1 − 5,67·(0,42 − χ)²) kg/h; kritický tok od P2 < 0,58·P1 | Spirax Sarco | FP.steam_kgs |
| Charakteristika parního ventilu | pro ohřev párou ekviprocentní; úbytek tlaku na ventilu ≥ 10 % | Spirax Sarco | Kv/Kvs = R^(zdvih − 1), R 30; Kvs dopočítané na 10 % |
| U pláště, nerez, míchaná voda | 850–1 700 W/(m²·K); vodné roztoky 450–1 140 | Spirax Sarco | rvpUAst 6,5 kW/K ≈ 5–6 m² × 1 100 (beze změny) |
| Stall | tlak v plášti pod protitlakem kondenzátu → kondenzát stojí, nerovnoměrný ohřev, rázy | TLV, Spirax Sarco | stCondBack, jWaterKg, jDrainKgS |
| Vzduch v páře | 2 bar abs. s 25 % vzduchu: manometr ukazuje 1 bar přetlaku (120 °C), pára má jen 112 °C; 1 mm vzduchu klade teplu odpor jako ~15 m mědi | Spirax Sarco | Daltonův zákon + odvzdušňovač jAirTau; ODHAD „1 % vzduchu = poloviční přestup na straně páry“ |
| Plášť pánve | na začátku varu vytlačit vzduch parou (1–4 odvzdušňovací trubky), na konci otevřít, jinak podtlak a zborcení dna; pára 2–3 bar; 2,5 m mladiny = +0,25 bar u dna | Kunze s. 290–291 | jVacBreaker, hlášení |
| Ohřev mladiny k varu | moderní pánev: na 100 °C za ~15 min | Kunze s. 299 | nemíchaná mladina 43 hl: 0,79 K/min (dřív 0,72) |
| Odpar | dnes 4–6 % celkem; dříve 8–12 %; 5–8 % objemu za hodinu | Kunze s. 299, EU JRC | 85 % páry u plné pánve: 8,8 %/h |
| pH za varu | nepřevařená 5,5–5,6 → vyražená 5,4–5,5; VLB 5,62 → 5,50 za 90 min | Kunze s. 286, VLB (Meyer, CBC 2015) | phBoilDrop 0,08/h |
| Okyselení mladiny | těsně před koncem varu na 5,1–5,2 (lepší lom, méně barvy, čistší hořkost, horší využití chmele) | Kunze s. 286 | tlačítko +100 mL 80% kyseliny mléčné |
| Dávka kyseliny | 30 mL 0,8% kyseliny mléčné na kg sladu → −0,1 pH mladiny (rmut 60 mL); příklad: 1 L nepřevařené mladiny z 5,54 na 5,20 = 0,15 g kyseliny | Kunze s. 229 | wortBuf 26,6 mEq/(kg·pH) → 530 mL 80 % na 700 kg = −0,30 pH |
| Barva za varu | 5,7 → 6,5 → 7,2 → 8,0 EBC za 0/30/60/90 min; nádoba plná 8,2 → vyražená 11,3 → po zchlazení poloviny 13,6 EBC | VLB (Meyer, CBC 2015) | colK100 1,2 EBC/h (bez zahuštění odparem, to model počítá zvlášť) |
| Ea tvorby barvy | 77 kJ/mol (65–100 °C), nad 100 °C 112 kJ/mol | Kroh et al., TU Berlín | colEa 77 |
| Barva v provozu | slad 3,9–4,2 → předek 6,3–6,6 → nepřevařená 8,8–9,0 → vyražená 8,8–10,9 → zákvasná 11,5–12,0 → pivo 7–8 EBC | Kunze s. 287 (obr. 3.67d) | odhad barvy piva = 0,65 × zákvasná |
| DMS za varu | DMS-P 230 → 82 µg/L, volný DMS 110 → 12 µg/L za 90 min | VLB | (Dickenson beze změny, jen pH mladiny) |
| Vířivka | nátok ≤ 3,5 m/s, co největší objemový tok, často stačí mnohem menší rychlost; klid 20–30 min; D : H 3 : 1 | Kunze s. 340–341 | wpVmax 3,5; wpVmin 1,0 (ODHAD); hrdlo = trubka z plánku |
| Horký kal | 0,2–0,4 % mladiny, částice 30–80 µm; 6,6–6,9 kg sušiny/100 hl u 12% | VLB | model ~2,4 kg lomu + chmel na 40 hl (sedí) |
| Chladič | jednostupňově ledová 1–2 °C → 80–88 °C, mladina 95–98 °C → zákvasná; ledová ~3 °C pod zákvasnou | Kunze s. 351–352 | návrh N1 (průtok ledové vody) |
| Kyslík po provzdušnění | 8–10 mg/L | VLB | návrh N6 |
| Ztráty povrchem | holá nerez ~15 W/(m²·K) při 0,5 m/s vzduchu; izolovaná ~0,8; holé víko pánve 9 m² ≈ 10 kW | inzonex (ISO 12241) | pipeU 10 (holá trubka bez průvanu) |
| Energie varny | infuze, 7,5 % odparu: rmutování 2,2 + ohřev k varu 3,4 + var 5,0 + CIP 0,3 + teplá voda 2,3 kWh/hl; 1 % odparu ≈ 0,67 kWh/hl | EU JRC | protokol ukáže kWh páry na hl |
| Mladina | c_p ≈ 4,0 kJ/(kg·K); otopná plocha vnějšího vařáku ~0,2 m²/hl | Briggs | c_p v modelu 3,87 při 12 °P (ponecháno) |
| Hustota vody | 998,2 (20 °C) … 958,4 (100 °C) kg/m³ | Kell 1975 | FP.water_rho |
| Sytá pára | tlak a teplota sytosti jako v parních tabulkách, i pro podtlak; výparné teplo 2 453,5 (20 °C), 2 256,5 (100 °C), 2 147,7 kJ/kg (138,9 °C) | IAPWS-IF97 | FP.psat, FP.tsat; FP.hfg proložené (chyba < 0,1 %) |

---

## 3. Co balíček mění (podrobně)

### P1. Pára do pláště: ventil, tlak v plášti, vzduch, kondenzát (`FP.steam_pd`)
- **Ventil:** Kv = Kvs × R^(zdvih − 1). Pod 5 % zdvihu klesá lineárně k nule.
  `stValveR` = 30 je ekviprocentní regulační ventil (ODHAD, typ ventilu u vás neznám), 1 je lineární ruční ventil.
  Kvs se bez údaje dopočítá tak, aby plně otevřený ventil při 60 °C ubral 10 % tlaku.
  Plně otevřená pára pak dá 96–98 % dřívějšího výkonu a kalibrace `rvpUAst` platí dál.
- **Tlak v plášti** se počítá z rovnováhy: pára ventilem (Spirax) = pára zkondenzovaná v plášti
  (UA·(T_sat − T)/h_fg). Výkon je tedy omezený buď ventilem (přiškrceno, studená náplň), nebo pláštěm
  (plně otevřeno, u varu).
- **Vzduch:** Daltonův zákon. Se vzduchem je pára v plášti chladnější a hůř předává teplo.
  Zavzdušňovací ventil (`jVacBreaker` = 1) drží při přiškrcené páře a po zavření páry ~1 bar abs.
  Pustí přitom do pláště vzduch, který pak po otevření páry vytlačí odvzdušňovač (`jAirTau`); ohřev chvíli nejede naplno.
  Bez zavzdušňovacího ventilu (`jVacBreaker` = 0) spadne plášť do podtlaku a trenažér varuje:
  „otevři odvzdušnění, hrozí zborcení dna“ (Kunze s. 290–291).
  Zjednodušení: na začátku várky je plášť bez vzduchu.
- **Kondenzát:** přitéká, co se zkondenzuje. Odvaděč odvede tím víc, čím víc je tlak v plášti nad protitlakem
  kondenzátu (`stCondBack` 0,15 bar ODHAD). Pod protitlakem neodtéká nic (stall) a plášť se zaplavuje;
  zaplavená část netopí. Poddimenzovaný odvaděč plášť zaplaví i při přetlaku. Pustíš-li páru naráz do zaplaveného
  pláště: hlášení **RÁZ V PLÁŠTI**.
- **Zavřená parní trasa** v plánku: pára nejde a kotel ji nevyrábí. Kotel dostává přesně ten výkon, který přijme plášť.
- Panel u řádku kotle ukazuje **tlak v plášti pánve** (přetlak, jako manometr), zaplavení kondenzátem a vzduch.

Výkon do 2 500 L vody podle zdvihu (spočteno modelem, Kvs dopočítané, pára 2,5 bar, míchadlo 35 Hz):

| Zdvih | 60 °C: dřív | lineární (R 1) | R 10 | **R 30 (výchozí)** | 95 °C: dřív | **R 30** |
|---|---|---|---|---|---|---|
| 25 % | 128 kW | 198 kW | 141 kW | **62 kW** (plášť 1,0 bar abs.) | 74 kW | **61 kW** (1,2 bar abs.) |
| 50 % | 256 kW | 386 kW | 250 kW | **144 kW** (1,0 bar abs.) | 147 kW | **142 kW** (1,8 bar abs.) |
| 75 % | 384 kW | 469 kW | 423 kW | **333 kW** (1,5 bar abs.) | 221 kW | **256 kW** (2,9 bar abs.) |
| 100 % | 511 kW | 490 kW | 490 kW | **490 kW** (3,2 bar abs.) | 295 kW | **289 kW** (3,4 bar abs.) |

Při 25–50 % zdvihu a náplni 60 °C je v plášti ~1 bar abs.: zavzdušňovací ventil drží atmosférický tlak, kondenzát
přitom neodtéká a plášť se pomalu zaplavuje (stall). U varu dává ekviprocentní ventil skoro stejný výkon jako
dřívější model. Lineární ventil dává většinu výkonu už v první polovině zdvihu.

### P2. Přestup tepla na straně náplně (`FP.film_hA`)
- **Míchání:** h ∝ N^⅔·μ^−⅓ (Chilton–Drew–Jebens). Reference je voda 60 °C při 35 Hz.
  Voda 20 °C předává o ~23 % hůř, vroucí voda o ~18 % líp; mladina 12,5 °P při 100 °C zhruba jako voda 60 °C.
- **Bez míchadla:** přirozená konvekce h ∝ (β·ΔT_stěna/ν)^⅓. Učebnicově (voda 60 °C, ΔT 30 K) je to ~0,46
  míchané hodnoty. Model má ale na straně náplně jen ~26 % celkového odporu, ve skutečnosti ~55 %.
  `hNatC` 0,28 proto vrací učebnicový poměr celkového prostupu bez míchání a s mícháním, ~0,6.
  Hustý rmut bez míchadla předá jen ~2 % (zdánlivá viskozita jako u čerpadel), takže se připaluje.
- Nemíchaná mladina 43 hl s plnou párou se ohřívá 0,79 K/min (dřív 0,72), s míchadlem 1,24 K/min (dřív 1,30).

### P3. pH mladiny (`FP.wort_ph`, `FP.boil_step`, `FP.acid_dose`)
- Sladina má pH rmutu + 0,05 (vyslazování, ODHAD). Za varu pH klesá o 0,08 za hodinu (VLB, Kunze).
- Tlačítko **Kyselina mléčná 80 % do mladiny +100 mL** funguje jen tehdy, když je v pánvi mladina.
  Pufr mladiny podle Kunzeho s. 229: 26,6 mEq na kg sladu a pH, takže 530 mL na 700 kg sníží pH o 0,3.
- pH mladiny teď řídí izomeraci chmele, SMM → DMS a barvu. Okyselení před koncem varu dá méně barvy a o něco
  menší hořkost. Okyselení na začátku varu zpomalí rozklad SMM, takže hrozí víc DMS.

### P4. Barva (`FP.color_step`)
- Přírůstek [EBC/h] = 1,2 × e^(−77 kJ/mol/R·(1/T − 1/373 K)) × e^(0,7·(pH − 5,5)) × °P/12. Pod 70 °C se barva netvoří.
  Zahuštění odparem přidává barvu zvlášť (barva je na litr).
- Barva se tvoří ve všech nádobách: při dekokci, ohřevu k varu, za varu, ve vířivce i během chlazení (mladina
  čeká ve vířivce). Při 95 °C je rychlost ~71 % rychlosti při 100 °C, při 80 °C ~25 %.
- Protokol ukáže i odhad barvy piva: 0,65 × zákvasná (Kunze s. 287: zákvasná 11,5–12 → pivo 7–8 EBC).

### P5. Vířivka (`FP.whirl_inlet`)
- Rychlost nátoku = průtok / průřez hrdla. `wpInletMM` 0 znamená stejný průměr jako trubka DN50 v plánku
  (75 mm podle `bore50`): 300 L/min ≈ 1,1 m/s. Když je hrdlo užší, zadej jeho průměr (50 mm → 2,5 m/s).
- Nad 3,5 m/s (Kunze) se část lomu roztříští a neusadí se; s odčerpanou mladinou ubývá.
  Trenažér varuje: „Zpomal čerpadlo“.
- Pod 1,0 m/s (ODHAD) se vířivka roztáčí slabě a kužel je horší.

### P6. Trubky (`FP.pipe_cool_k`)
- τ = (C_vody + C_oceli)/(U·π·D_vnější) na metr. Plná trubka DN50 z plánku (75 mm) za hodinu stání: 80 → 59 °C.
  Dřív za 30 min skoro na teplotu okolí.

### P7. Objem horké kapaliny podle Kella místo lineární roztažnosti.

---

## 4. Návrhy, které v balíčku nejsou (potřebují tvoje údaje nebo rozhodnutí)

| # | Návrh | Proč | Co potřebuju |
|---|---|---|---|
| N1 | **Průtok ledové vody** nastavitelný nebo podle křivky čerpadla (teď pevně 120 L/min) | Kunze: ledová 1–2 °C se ohřeje na 80–88 °C jen při poměru ~1,05–1,1 hl vody na hl mladiny. Teď při 70 L/min mladiny teče do bojleru voda jen ~50 °C | jak se u vás seřizuje průtok ledové (klapka, měnič?) |
| N2 | Odpar z volné hladiny před varem a ve vířivce (komín) | reálná ztráta tepla a pokles teploty ve vířivce | teplota ve vířivce na začátku a na konci klidu |
| N3 | Zanášení otopné plochy (připálení) během várky a jeho odstranění louhem (CIP ↔ přestup tepla) | špinavá pánev topí pomaleji, proto má CIP smysl | doba ohřevu čisté pánve a pánve po várce |
| N4 | pH rmutu během rmutování klesá o 0,15–0,30 (Kosa s. 137); pH výstřelků roste s alkalitou vyslazovací vody | třísloviny počítat z pH poslední sladiny, ne z pH rmutu | rozbor vody, pH poslední sladiny |
| N5 | Rozpustnost α-kyselin a ztráty izo-α na kalech místo pevného faktoru 0,44 | využití chmele klesá s dávkou | laboratorní IBU vyražené mladiny a piva |
| N6 | Kyslík: vystírání shora, čerpání, provzdušnění 8–10 mg/L podle teploty a °P | kyslík při vystírání = tmavší barva, horší stabilita | – |
| N7 | Hydrostatický tlak u dna: 2,5 m mladiny → +0,25 bar → u dna vře až při 102–103 °C (Kunze s. 290–291) | teplota stěny, připalování, var u dna | – |
| N8 | Výkon míchadla Np·ρ·N³·D⁵ (teplo do rmutu ~0,5–2 kW) | malý, ale měřitelný vliv při prodlevách | štítek motoru míchadla |
| N9 | Rozpad kužele kalu na konci stahování z vířivky (Kunze: na konci zpomalit) | kal v posledních hl | – |
| N10 | Stejný model ventilu a pláště i pro bojler (parní had) | jednotná fyzika páry | – |
| N11 | Hodnotit barvu proti odhadu barvy piva, ne proti zákvasné mladině | cíl receptu 9 EBC je nejspíš barva piva | potvrď, co znamená EBC v receptu |
| N12 | Kyselina mléčná do rmutu: 80 % = 10,6 mEq/mL (teď 11,8 = 88 %) | účinek je teď o 11 % silnější | jakou kyselinu používáte (80 / 88 %) |
| N13 | Poměr odporů pára/náplň (HA_REF): ve skutečnosti ~55 % na straně náplně, v modelu ~26 % | míchadlo, viskozita a teplota by pak působily víc; znamená to znovu nastavit `mashFilmK` | doby ohřevu rmutu s míchadlem a bez něj |
| N14 | Připalování: místo ztráty 10 % výkonu (viz nález 10) horší přestup přes nános | bilance energie sedí i při připalování | – |

---

## 5. Co změřit na Zajíci, aby to sedělo

1. **Parní ventil pánve:** typ (ruční / regulační), štítek (Kvs, DN), jestli má plášť zavzdušňovací a odvzdušňovací
   ventil a kam teče kondenzát (protitlak).
2. **Manometr na plášti** (pokud ho máte): tlak při 25 / 50 / 75 / 100 % páry na studenou a na horkou náplň.
   Porovnej s tabulkou v P1, z toho se pozná typ ventilu.
3. **Doby ohřevu:** 2 500 L rmutu 50 → 63 °C při známém otevření páry; plná pánev mladiny 72 °C → var
   s míchadlem a bez něj.
4. **Vířivka:** průměr nátokového hrdla, průtok C1 při vyrážení, teplota na začátku a na konci klidu.
5. **pH a barva:** pH sladiny před varem a vyražené mladiny, EBC vyražené a zákvasné mladiny a piva.
6. **Rozbor vody** (alkalita, Ca, Mg); výchozí odhad dává pH rmutu 5,84.

Hodnoty vlož do `kalibrace.json`, nebo mi je pošli a nastavím je.

---

## 6. Ověření

- **Testy na v70 / v152:** 2D (Godot 4.3) 305 kontrol, 0 selhání; 3D (Godot 4.7.2) 305 kontrol, 0 selhání.
  Z toho 36 nových „FP …“ kontrol (pára a plášť, přestup tepla, pH, barva, vířivka, trubky, objem)
  a 2 upravené staré (H9f, H9g): reference přestupu tepla se teď měří při 60 °C.
- **Starší verze:** skript prošel i na 2D v67 (304 kontrol, 0 selhání) a 3D v133 (238 kontrol, 0 selhání).
  Starší 3D násobí filmem v `heat()`, skript to pozná. Verze bez korekce pH izomerace (`isoPh`) ji dostane jako násobek
  a referenční test izomerace pak běží při pH 5,5. U v133 se 2 volitelné háčky testů přeskočí, protože tam ty testy ještě nejsou.
- **Vkládací skript:** zvládá Windows (výpis v cp1250), soubory s CRLF i spuštění ze složky projektu.
  Po aktualizaci programu obnoví zálohy. Když místo nenajde jednoznačně, háček nevloží a napíše proč.
- **Automatická várka 12,5° (700 kg), v70 bez a s FYZIKA+:**

| Veličina | v70 | v70 + FYZIKA+ | Reálně (zdroj) |
|---|---|---|---|
| Objem ve spilce | 37,6 hl | 37,4 hl | – |
| Stupňovitost | 12,68 °P | 12,76 °P | – |
| IBU | 33,1 | 33,0 | cíl 32 |
| Barva vyražené mladiny | – | 11,6 EBC | 8,8–10,9 pro slad 3,9–4,2 EBC (Kunze s. 287); tvůj šrot má ~4,5 → ~9,7–12,0 |
| Barva ve spilce | 11,3 EBC | 12,8 EBC | zákvasná 11,5–12,0 (Kunze s. 287) → pro tvůj šrot ~12,6–13,2 |
| Odhad barvy piva | – | 8,3 EBC | cíl receptu 9 |
| DMS | 15,9 ppb | 16,4 ppb | < 60 ppb |
| pH vyražené mladiny | (pH rmutu 5,84) | 5,78 | 5,4–5,5 při běžné vodě |
| Pára na varnu | – | 20,6 kWh/hl | JRC: infuze 13,2 kWh/hl; + dekokce (+10–20 %) a vyšší odpar (+0,67 kWh/hl na 1 %) ≈ 18–19 |
| Výtěžnost varny | 73,8 % | 73,8 % | 75–80 % (Kunze s. 323) |
| Délka várky | 637 min | 643 min | – |

Barva teď sedí do rozmezí z provozu (přepočteného na tvůj šrot). Dřívější model byl spíš světlý, protože barva
přibývala jen za varu. Výchozí voda (pH rmutu 5,84) barvu zvyšuje: Maillardova část barvy vzniká při pH 5,84
o ~18 % rychleji než při pH 5,6.

---

## Zdroje

- Spirax Sarco – Control valve sizing for steam systems; Heating with coils and jackets; Air venting theory. https://spiraxsarco.com/learn-about-steam
- TLV – Stall phenomenon; Temperature problems caused by air. https://www.tlv.com/steam-info/steam-theory
- B. Meyer (VLB Berlin): Wort boiling, Craft Brewers Conference 2015. https://www.craftbrewersconference.com/wp-content/uploads/2015_presentations/W1440_Burghard_Meyer.pdf
- Kroh et al. (TU Berlín): Simplified kinetics and colour formation in sucrose solutions based on α-dicarbonyl compounds. https://depositonce.tu-berlin.de/items/13e09ab2-3369-4ced-86fc-e2eccb232d73
- EU JRC – Best environmental management practice, brewery energy. https://greenbestpractice.jrc.ec.europa.eu/print/pdf/node/237
- Briggs of Burton – Brewhouse heating (IBD 2017). https://briggsofburton.com/wp-content/uploads/technical-papers/IBD-DCCC-BHHeat-Jan-2017-Briggs.pdf
- Inzonex – Heat loss from brewery kettles, tuns & whirlpool. https://inzonex.co.uk/calc/articles/brewery-heat-loss-kettles-tuns/
- IAPWS-IF97 (průmyslová formulace vlastností vody a páry), oblast 4; G. S. Kell (1975): hustota vody 0–150 °C.
- W. Kunze: Technology Brewing and Malting, 3. angl. vyd. (s. 229, 286–287, 290–291, 299, 323, 340–341, 351–352) a Kosa,
  Procházka: Technologie výroby sladu a piva (s. 136–137, 163). Jen čísla s odkazem na stranu, bez textu knih.
