extends Node
## Generátor realistických 2D spritů: vyrenderuje 3D modely (ortografický pohled zepředu) do PNG v art/.
## Spuštění: godot --path . res://sprites.tscn --rendering-driver vulkan
var PPM := 1400.0     # pixelů na metr (1 px plánu = 5 mm → 7 px)
var V

func _ready() -> void:
	V = load("res://view3d.gd").new()
	V.init_mats()
	var jobs := [
		["valve_open", Vector2(0.62, 0.62), Vector2(0, 0.14), Callable(self, "_valve").bind(0.0)],
		["valve_closed", Vector2(0.62, 0.62), Vector2(0, 0.14), Callable(self, "_valve").bind(PI / 2.0)],
		["valveh_open", Vector2(0.62, 0.62), Vector2(0, 0.14), Callable(self, "_valve").bind(0.0, true)],
		["valveh_closed", Vector2(0.62, 0.62), Vector2(0, 0.14), Callable(self, "_valve").bind(PI / 2.0, true)],
		["pump", Vector2(1.25, 0.95), Vector2(0.3, 0.08), Callable(self, "_pump")],
		["pump_inline", Vector2(1.0, 0.95), Vector2(0.0, 0.28), Callable(self, "_pump_inline")],
	]
	if "--vs" in OS.get_cmdline_user_args(): jobs = []
	if "--valves" in OS.get_cmdline_user_args(): jobs = jobs.slice(0, 4)
	for j in jobs:
		PPM = 1400.0
		await _render(j[0], j[1], j[2], j[3])
	PPM = 700.0
	var vj := [
		["vs_body", Vector2(1.9, 1.4), Vector2(0, 0), Callable(self, "_vs_body")],
		["vs_dome", Vector2(1.9, 0.32), Vector2(0, 0.16), Callable(self, "_vs_dome")],
		["vs_dish", Vector2(1.9, 0.3), Vector2(0, -0.15), Callable(self, "_vs_dish")],
		["vs_cone", Vector2(1.9, 1.0), Vector2(0, 0), Callable(self, "_vs_cone")],
		["vs_horiz", Vector2(3.4, 1.45), Vector2(0, 0), Callable(self, "_vs_horiz")],
	]
	if "--valves" in OS.get_cmdline_user_args(): vj = []
	for j in vj:
		await _render(j[0], j[1], j[2], j[3])
	get_tree().quit()

func _render(nm: String, world: Vector2, center: Vector2, builder: Callable) -> void:
	var px := Vector2i(int(world.x * PPM), int(world.y * PPM))
	var vp := SubViewport.new(); vp.size = px; vp.transparent_bg = true; vp.msaa_3d = Viewport.MSAA_8X
	vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS; add_child(vp)
	var root := Node3D.new(); vp.add_child(root)
	var e := Environment.new(); e.background_mode = Environment.BG_CLEAR_COLOR
	var sk := Sky.new(); var psm := PanoramaSkyMaterial.new(); psm.panorama = V._pano(); sk.sky_material = psm; e.sky = sk
	e.ambient_light_source = Environment.AMBIENT_SOURCE_SKY; e.ambient_light_energy = 0.9; e.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	e.tonemap_mode = Environment.TONE_MAPPER_ACES; e.tonemap_exposure = 1.1
	e.ssao_enabled = true; e.ssao_radius = 0.1; e.ssao_intensity = 2.5
	var we := WorldEnvironment.new(); we.environment = e; root.add_child(we)
	var sun := DirectionalLight3D.new(); sun.rotation_degrees = Vector3(-35, -30, 0); sun.light_energy = 1.1; sun.shadow_enabled = true; root.add_child(sun)
	var fill := DirectionalLight3D.new(); fill.rotation_degrees = Vector3(-10, 60, 0); fill.light_energy = 0.4; root.add_child(fill)
	V.W = root
	builder.call(root)
	var cam := Camera3D.new(); cam.projection = Camera3D.PROJECTION_ORTHOGONAL; cam.size = world.y; cam.near = 0.1; cam.far = 20
	cam.position = Vector3(center.x, center.y, 5.0); root.add_child(cam)
	for i in 6: await RenderingServer.frame_post_draw
	var img := vp.get_texture().get_image()
	img.save_png("res://art/%s.png" % nm)
	print("sprite ", nm, " ", img.get_size())
	vp.queue_free()

func _valve(root: Node3D, lever_ang: float, hard := false) -> void:
	var gc := Color(0.08, 0.55, 0.22) if lever_ang < 0.1 else Color(0.75, 0.1, 0.08)
	if hard: gc = Color(0.1, 0.3, 0.8)
	var n0 := Node3D.new(); root.add_child(n0)
	var n := Node3D.new(); n0.add_child(n)
	n0.rotation.x = deg_to_rad(34.0)   # kamera mírně shora: páka mířící k divákovi je vidět
	var rp := 0.028
	V._ring(n, Vector3.ZERO, rp * 1.5, 0.085, V.steel_b)
	for s in [-1.0, 1.0]:
		V._ring(n, Vector3(s * 0.052, 0, 0), rp * 1.95, 0.016, V.steel_p)
		V._ring(n, Vector3(s * 0.075, 0, 0), rp * 1.7, 0.022, V.steel_p)
		V._ring(n, Vector3(s * 0.094, 0, 0), rp * 1.15, 0.024, V.steel_b)     # nátrubek trubky
	V._add(n, V._cyl(0.026, 0.075, 24), Vector3(0, 0.082, 0), V.steel_p)
	var stem := Node3D.new(); stem.position = Vector3(0, 0.125, 0); n.add_child(stem)
	V._add(stem, V._cyl(0.03, 0.022, 24), Vector3.ZERO, V.steel_p)
	var hold := Node3D.new(); hold.rotation.y = lever_ang; stem.add_child(hold)
	V._add(hold, V._box(Vector3(0.2, 0.009, 0.026)), Vector3(0.1, 0.014, 0), V.steel_p)
	V._add(hold, V._box(Vector3(0.105, 0.03, 0.038)), Vector3(0.24, 0.014, 0), V._mat(gc, 0.5, 0.0))
	for k in range(5): V._add(hold, V._box(Vector3(0.005, 0.032, 0.04)), Vector3(0.2 + k * 0.02, 0.014, 0), V._mat(gc.darkened(0.45), 0.7, 0.0))
	V._add(stem, V._cyl(0.012, 0.03, 12), Vector3(0, 0.03, 0), V.steel_p)

func _pump(root: Node3D) -> void:
	var n := Node3D.new(); root.add_child(n)
	# hlava (voluta) – pohled z boku: kruh, sání vlevo, výtlak nahoru
	V._add(n, V._cyl(0.14, 0.1, 48), Vector3(0, 0, 0), V.steel_b, Vector3(PI / 2, 0, 0))
	V._add(n, V._cyl(0.1, 0.104, 48), Vector3(0, 0, 0.002), V.steel_p, Vector3(PI / 2, 0, 0))
	for k in range(8):
		var a := TAU * k / 8.0
		V._add(n, V._cyl(0.011, 0.014, 10), Vector3(cos(a) * 0.12, sin(a) * 0.12, 0.054), V.steel_p, Vector3(PI / 2, 0, 0))
	V._ring(n, Vector3(-0.2, 0, 0), 0.052, 0.24, V.steel_b)
	V._ring(n, Vector3(-0.32, 0, 0), 0.07, 0.016, V.steel_p)
	V._ring(n, Vector3(-0.34, 0, 0), 0.06, 0.02, V.steel_p)
	V._add(n, V._cyl(0.048, 0.2, 24), Vector3(0, 0.2, 0), V.steel_b)
	V._add(n, V._cyl(0.07, 0.016, 24), Vector3(0, 0.31, 0), V.steel_p)
	V._add(n, V._cyl(0.06, 0.02, 24), Vector3(0, 0.33, 0), V.steel_p)
	# lucerna, motor s žebry, kryt ventilátoru
	V._ring(n, Vector3(0.17, 0, 0), 0.095, 0.1, V.steel_b)
	V._ring(n, Vector3(0.45, 0, 0), 0.108, 0.46, V.steel_b)
	for i in range(11): V._ring(n, Vector3(0.26 + i * 0.038, 0, 0), 0.116, 0.014, V.steel_p)
	V._ring(n, Vector3(0.7, 0, 0), 0.105, 0.07, V._mat(Color(0.11, 0.12, 0.14), 0.55, 0.3))
	V._add(n, V._box(Vector3(0.12, 0.07, 0.11)), Vector3(0.45, 0.14, 0), V.steel_b)
	V._add(n, V._box(Vector3(0.1, 0.012, 0.09)), Vector3(0.45, 0.18, 0), V.steel_p)
	# rám
	V._add(n, V._box(Vector3(0.9, 0.025, 0.3)), Vector3(0.28, -0.2, 0), V.steel_b)
	for sx in [0.0, 0.5]:
		V._add(n, V._box(Vector3(0.05, 0.08, 0.2)), Vector3(sx, -0.145, 0), V.steel_b)

func _pump_inline(root: Node3D) -> void:
	var n := Node3D.new(); root.add_child(n)
	var dn := 0.0255
	# trubka skrz čerpadlo se dvěma tri-clamp spoji
	V._ring(n, Vector3.ZERO, dn, 0.76, V.steel_b)
	for s in [-1.0, 1.0]:
		V._ring(n, Vector3(s * 0.31, 0, 0), dn * 1.75, 0.014, V.steel_p)
		V._ring(n, Vector3(s * 0.335, 0, 0), dn * 1.95, 0.02, V.steel_p)
		V._ring(n, Vector3(s * 0.2, 0, 0), dn * 1.5, 0.12, V.steel_b)
	# hlava (voluta) zepředu: kruh s víkem a šrouby
	V._add(n, V._cyl(0.15, 0.1, 56), Vector3(0, 0, 0), V.steel_b, Vector3(PI / 2, 0, 0))
	V._add(n, V._cyl(0.115, 0.108, 56), Vector3(0, 0, 0.002), V.steel_p, Vector3(PI / 2, 0, 0))
	V._add(n, V._cyl(0.06, 0.112, 40), Vector3(0, 0, 0.004), V.steel_b, Vector3(PI / 2, 0, 0))
	for k in range(10):
		var a := TAU * k / 10.0
		V._add(n, V._cyl(0.012, 0.014, 10), Vector3(cos(a) * 0.132, sin(a) * 0.132, 0.058), V.steel_p, Vector3(PI / 2, 0, 0))
	# lucerna + motor nahoře (svisle) s žebry a krytem ventilátoru
	V._add(n, V._cyl(0.1, 0.09, 36), Vector3(0, 0.19, 0), V.steel_b)
	V._add(n, V._box(Vector3(0.22, 0.03, 0.05)), Vector3(0, 0.15, 0), V.steel_p)
	V._add(n, V._cyl(0.105, 0.3, 40), Vector3(0, 0.39, 0), V.steel_b)
	for i in range(8): V._add(n, V._cyl(0.114, 0.012, 40), Vector3(0, 0.27 + i * 0.037, 0), V.steel_p)
	V._add(n, V._cyl(0.1, 0.07, 36), Vector3(0, 0.575, 0), V._mat(Color(0.11, 0.12, 0.14), 0.55, 0.3))
	V._add(n, V._box(Vector3(0.1, 0.07, 0.11)), Vector3(0.12, 0.4, 0), V.steel_b)

func _vs_body(root: Node3D) -> void:
	V._add(root, V._cyl(0.95, 1.4, 72), Vector3.ZERO, V.inox)

func _vs_dome(root: Node3D) -> void:
	var prof: Array = []
	for i in range(0, 21):
		var t := float(i) / 20.0 * PI * 0.5
		prof.append(Vector2(0.95 * cos(t), 0.32 * sin(t)))
	V._add(root, V._lathe(prof, 72, Vector2(8, 1.6)), Vector3.ZERO, V.inox)

func _vs_dish(root: Node3D) -> void:
	var prof: Array = []
	for i in range(0, 21):
		var t := float(i) / 20.0 * PI * 0.5
		prof.append(Vector2(0.95 * sin(t), -0.3 * cos(t)))
	V._add(root, V._lathe(prof, 72, Vector2(8, 1.6)), Vector3.ZERO, V.inox)

func _vs_cone(root: Node3D) -> void:
	V._add(root, V._cyl(0.95, 1.0, 72, 0.09), Vector3.ZERO, V.inox)

func _vs_horiz(root: Node3D) -> void:
	var rr := 0.725
	var prof: Array = []
	for i in range(0, 13):
		var t := float(i) / 12.0 * PI * 0.5
		prof.append(Vector2(rr * sin(t), -1.7 + 0.3 * (1.0 - cos(t))))
	prof.append(Vector2(rr, 1.4)); 
	for i in range(1, 13):
		var t2 := float(i) / 12.0 * PI * 0.5
		prof.append(Vector2(rr * cos(t2), 1.4 + 0.3 * sin(t2)))
	V._add(root, V._lathe(prof, 72, Vector2(8, 1.6)), Vector3.ZERO, V.inox, Vector3(0, 0, PI / 2))
