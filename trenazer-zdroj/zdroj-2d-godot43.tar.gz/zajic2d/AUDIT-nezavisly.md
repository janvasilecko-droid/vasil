# Nezávislý technický audit – Trenažér varny Zajíc (2D, Godot 4.3)

Datum: 22. 10. 2026. Ověřeno spuštěním v Godot 4.3 (headless + GUI v xvfb), ne jen čtením kódu.
Všechny čísla níže jsou z běhu `--autotest --autodt=2` (automatická várka, recept 12,5° Zajíc, 700 kg sladu) a z `--tests`.

> Důležité: **nic z toho není porovnané s provozním měřením na skutečné varně.** Testy ukazují vnitřní konzistenci modelu, ne shodu s realitou.

---

## 1. Skutečný stav projektu

| Co | Kde | Poznámka |
|---|---|---|
| Fyzikální jádro (nádoby, teplo, enzymy, lože, chmel, chlazení, potrubí FIFO, hydraulika čerpadel) | `sim.gd` (~2600 ř.), `sim_step()`, `net_step()` | jedna velká třída, fyzika a síť dohromady |
| Voda/pH, kvašení, CIP, poruchy, hodnocení | `proc.gd` | `mash_ph`, `fer_step`, `cip_step`, `faults_step`, `scorecard` |
| Automatická várka | `auto.gd` (`tick`, `start`) | používá stejné `sim_step` a skutečné klapky přes `route_valves` |
| Automat scezování | `lauter_auto.gd` | cílí na Δp ~50 mbar, kypří podle Δp |
| Postup / úkoly | `training.gd` (`STEPS`, `current()`) | podmínky z fyzikálního stavu, ne z času |
| Rozvaděč RT.20 | `cabinet.gd` (`act`, `_draw`, `hit`) | vazby na stav `S.cab`, `S.p*` |
| Vykreslení, vstupy, ukládání | `main.gd` (`save_game`/`load_game`, `_tap`, vrstvy) | |
| UI | `ctl.gd` (panel), `game.gd` (úkol, oznámení, zvuky), `oppanel.gd` (nepoužitý alternativní pult) | |
| Registr parametrů (nové) | `params.gd` → `PARAMETRY.md` | jednotka, zdroj, nejistota |
| Testy | `tests.gd` + `audit_tests.gd` | **165 kontrol, 165 prošlo** (22. 10. 2026) |

Sestavení: `godot --headless --path . --export-pack WinPack "Trenazer varny.pck"` (preset WinPack), pck se načítá k existujícímu `Trenazer varny.exe` (Godot 4.3). Aktualizace přes GitHub `trenazer2d/` – načte `boot.gd`.

Vizuální / zjednodušené: vířivá káď (oddělení kalů empiricky přes čas klidu), DMS a EBC (empirické), CIP (jen teplota a čas), kvašení (jedno-substrátový Monod bez CO₂).

---

## 2. Hmotnostní bilance a výtěžnost

**Vzorce** (`sim.gd`):
- Potenciální (laboratorní) extrakt: při vystírání `S.extIn += pot`, kde `pot = m · (1 − vlhkost) · extrakt_v_sušině` (`maltExtract 80 %`, `maltMoist 4,5 %`, sladové složky z `MALTS`).
- Extrakt ve spilce: `e_sp = sp.f + sp.n` [kg]; °P = `100 · e / (e + w)`; ρ ≈ `1 + 0,004 · °P`; V20 = `(w + e) / ρ`.
- **Výtěžnost 69 %** v protokolu = `e_sp / m_slad · 100` = **výtěžnost do spilky** (extrakt ve spilce na kg sladu v původním stavu), **není to podíl z potenciálu**.
- Nově doplněno (`yields()`): `VV_varna = e_vyr / m_slad` (extrakt ve vyrážce), `VV_cz = V_hor · 0,96 · ρ · P / m_slad` (provozní výpočet z objemu horké vyrážky), `ucinnost = e_vyr / e_lab`.

**Referenční automatická várka (700 kg sladu, ne 680 kg):**

| Veličina | Hodnota |
|---|---|
| Laboratorní extrakt sladu `e_lab` | **538,50 kg** (= 700 · 0,955 · ~0,805) |
| Vyrážka (horká) | 4 171 L, 11,89 °P, **e_vyr = 498,7 kg** |
| Výtěžnost varny VV (extrakt ve vyrážce / slad) | **71,2 %** (z objemu ×0,96: 71,2 %) |
| Využití lab. extraktu | **92,6 %** |
| Spilka | 38,9 hl (20 °C), 11,90 °P, **e_sp = 484,9 kg** → výtěžnost do spilky **69,3 %** |
| Zbytek extraktu | SK 18,7 kg (sladina v mlátě), potrubí 15,3 kg, vířivka 12,7 kg, pánev 2,5 kg, neztekucený škrob v loži 4,4 kg, kanál 0 kg |
| Bilance | nalezeno 538,49 kg vs vystřeno 538,50 kg (rozdíl 0,02 kg) |

**Odpovědi:**
1. 69 % = extrakt ve spilce / hmotnost sladu. Je to realistická výtěžnost do spilky (varna ~71 %, lab. 77 %).
2. Teoretický extrakt 538,5 kg; do vyrážky 498,7 kg (−7,4 % v mlátě/vyslazení), do spilky 484,9 kg.
3. **Ne.** 538,5 kg je potenciál sladu, ne extrakt mladiny. 40 hl × 12,5 °P ≈ **525 kg** extraktu – to by znamenalo 97,5 % potenciálu, což je nereálné. Model proto skutečně dosáhne jen **38,9 hl × 11,9 °P**.
   **Závěr: recept 12,5° (700 kg) nedosáhne cíle 40 hl 12,5 °P při realistické výtěžnosti. Potřeba ≈ 760 kg sladu** (při 69 % do spilky). Program teď na začátku várky vypíše „Kontrola receptu“ s tímto výpočtem. Výsledek jsem **nepřepisoval**.
4. Ano – každý přenos jde přes `takePart`/`addTo`/FIFO potrubí; test „ZADÁNÍ bilance extraktu“ (přečerpání 4 min) drží 200,000 → 200,000 kg.
5. Ztráty: sladina zadržená v mlátě (`skRetentionLkg 1,56 L/kg`), potrubí (FIFO obsah), mrtvý objem vířivky, překypění/přetečení (`drainExt`), neztekucený škrob v loži (`sk.lost`). Všechny mají fyzikální příčinu v kódu.
6. **Ano, může.** Uzavřená bilance jen dokazuje, že se nic nevytvoří ani neztratí – ne že jsou správné rozdělovací koeficienty (retence v mlátě, účinnost vyslazení, enzymatika). To se dá ověřit jen měřením.

---

## 3. Parní ohřev a var

- Tlak: `Tst = tsat(steamBar + 1,013)` – **absolutní tlak správně** (2,5 bar g → 3,51 bar abs → 138,9 °C z tabulky `TSAT`).
- Výkon do pláště: `_pd()`: `P = UA_st · heat · wet · (Tst − T)`, `UA_st = 6,5 kW/K` (ESTIMATED), `wet` = smáčená část pláště podle náplně (do 2 200 L).
- **Ventil je lineární:** `heat` (0–1) násobí UA → % otevření = % přestupu. **Zjednodušení** – skutečný ventil má nelineární charakteristiku a omezení průtokem páry. Kotel omezuje: `S.boiler.scale` při překročení 650 kW (ESTIMATED/MANUFACTURER).
- Kapacita: náplň `cC = 4,19 · w + 1,5 · (extrakt + sušina)` kJ/K, ocel `rvpSteel 450 kg` × 0,5 kJ/(kg·K).
- Ztráty: `rvpUA 0,25 kW/K` × (T − okolí).
- Čidlo: 1. řád, τ = 20–90 s podle míchání (`Tsens`).
- Var: nad bodem varu `Tb = tbWater + 0,03·°P` se přebytek tepla odpaří: `ev = E / 2257` (energie se neztrácí).
- **Kontrola řádu (test):** 2 000 L, 60 % páry: model 2,30 K/min → 321 kW jen na vodu. Ručně: 6,5 · 0,6 · 0,9 · (138,9 − 45) ≈ 330 kW → sedí.
- Energie: test „bilance energie“ 0,0 %; nezávislost na kroku 1 s vs 5 s: 0,03 °C.
- **Doložené:** nic není změřené. 650 kW a 2,5 bar = údaj provozovatele; UA, ocel, ztráty = odhady.

## 4. Rmutování a dekokce

- Dekokce se **počítá**, ne nastavuje: odběr rmutu je `takePart` (voda, extrakt, škrob, sušina, teplota), návrat `addTo` → teplota ze směšovací bilance (včetně oceli). Program teplotu po spojení nenastavuje.
- Enzymy: α/β-amyláza, aktivita podle teploty (Arrhenius + denaturace), pH faktor `exp(−((pH−5,7)/0,8)²)` resp. 5,5/0,7 (`proc.ph_factors`), mazovatění škrobu podle teploty, zcukření z poměru škrob/dextriny.
- Jodová zkouška = indikátor z podílu nezcukřeného škrobu (orientační, ne laboratorní).
- Citlivost na prodlevy: postup vyžaduje souvislou prodlevu v pásmu (±2 °C), hodnocení nově měří podíl času v ±0,5 °C.
- Omezení: složení sladu (enzymatická síla) jen koeficient `enz`; bez kalibrace na reálné várce.

## 5. Scezovací káď

**Rovnice** (`skRes`, `skDraw`):
- `Δp = Q · R`, `R = μ · (L/k + Lt/kt) / (A · (1 + 1,5·ch))`
- `k = k0 · mlýn / (1 + 2,5·c) / (1 + Δp / 30 kPa)`, `k0 = 1e-11 m²` (ESTIMATED), mlýn 0,6/1,0/1,5
- `L = m_slad · 0,0027 / A` → **700 kg → 0,36 m lože** (literatura 0,3–0,5 m ✔)
- `μ(T,P) = 2,414e-5 · 10^(247,8/(T+133,15)) · exp(0,025·P)` [Pa·s]
- slehávání: pod `skDpCompact` (80 mbar) pomalé, nad ním kvadraticky; nad `skDpChannel` (160 mbar) kanálky. **Obě hranice jsou teď kalibrovatelné parametry** (ESTIMATED, ne konstanty).

**Výpočet scénáře z běhu** (automat scezování, lauterlog): Δp drží 55 mbar, průtok 38 → 64 L/min (5–12 L/(min·m²)), první sladina 20,1 °P, konec 3,4 °P, scezování ≈ 75 min. Q_max při stejném stavu 150–250 L/min.

**Odpovědi:**
1. Průtok je **vypočítaný** z odporu lože (Darcy) a z požadavku C2 (`Q = min(požadavek, Qmax)`).
2. Když C2 chce víc: `ratio > 1` → podtlak pod sítem (`sk.vac`), Δp roste, lože se slehává (c ↑), kanálky; hlášení.
3. 80 / 160 mbar jsou **empirické prahy (odhad)**, nemají přesný fyzikální význam; teď jsou v `kalibrace.json`.
4. Kypření: řeže horní těsto podle hloubky (mělké/hluboké), snižuje zhutnění `c` a kanálky úměrně hloubce; hluboké uvolní víc jemných částic (zákal). Závisí na stavu lože, ale koeficienty jsou odhad.
5. 40 L/min a ~90 min: model dává 38–64 L/min a ~75 min při Δp 55 mbar. **Kritika:** Q_max 150–250 L/min ukazuje, že `k0` je spíš na horní hraně; reálná káď by se při 150 L/min utáhla dřív. → kalibrovat `skPerm` podle měřeného Δp (tlakoměr pod sítem) nebo podle průtoku, při kterém se lože začne utahovat.
6. **Chyba parametru:** viskozita sladiny roste s °P víc, než udává `exp(0,025·P)` (12 °P → ×1,35; literatura ≈ ×1,6–1,8). Kompenzuje to odhad `k0`, ale **je to nesprávný koeficient** → doporučuji `0,045`/°P a překalibrovat `k0`.

## 6. Čerpadla, klapky a potrubí

- Křivka: `H = H0 − 0,25·H0·(Q/Qn)²`, C1 32 m/400, C2 22 m/150, C3 26 m/200 (**ESTIMATED – chybí štítky**). C4, C5 nemají hydraulický model (pevný průtok `waterFlow`, okruh ledovky) – **zjednodušení**.
- Ztráty: Darcy–Weisbach + Swamee–Jain (laminárně 64/Re), DN 25/40 → Ø50, DN 50 → Ø75 (ESTIMATED), délky = délka v plánku × `pipeLenScale 0,4` (ESTIMATED), klapka `K = 0,4 + 0,6/p⁴`, chladič `4 · (Q/200)²` m.
- Pracovní bod: `pump_point()` hledá průsečík (bisekce), měnič drží průtok do 50 Hz → **je to průsečík charakteristik**, ne procento nastavení. Výškové rozdíly z plánku (hladina vs výtlak).
- NPSH: dostupná = atm + hladina − tlak par − ztráty sání; kavitace → hlášení a pokles průtoku. Zavodnění: `prime` 0–1, vzduch `airLock`, chod nasucho → vypnutí.
- Zavřená klapka průtok zastaví (BFS přes `valve_open`; testy D a „vše zavřené“ = 0 L). Nepropojená zařízení – ne, tok jen po hranách sítě.
- **Chyba z provozu opravená dnes:** staré uložení dávalo všem klapkám 50 % → velký odpor tras (verze 2).

## 7. Var, chmel, vířivka, chlazení

- Odpar z energie (viz 3), °P roste odparem (hmotnost vody klesá).
- IBU: izomerace Malowicki `k(T)`, rozpustnost/využití podle °P, výsledné `IBU = iso · 1000 / V20 · 0,44` – **faktor 0,44 je empirický** (ztráty na kalech, kvašení). Výsledek 29 IBU vs cíl 32 (recept 12,5°) – nepřepisováno; příčinou jsou odhadnuté α a faktor.
- DMS: SMM → DMS (Arrhenius), odpar úměrný intenzitě varu – **orientační**.
- Vířivka: kaly klesají po době víření/klidu – **empirické**, bez hydrodynamiky.
- Chladič: **ε-NTU** pro protiproud (`eff = (1 − x)/(1 − Cr·x)`), UA1 25, UA2 12 kW/K (ESTIMATED); výstup z průtoků a teplot, ne pevný. 2. zákon testován.
- Ledovka: 10 000 L s vlastní tepelnou kapacitou, agregát 45 kW (MANUFACTURER) zvlášť – nádrž se při chlazení ohřívá, agregát ji zpět chladí. Teplá voda z 1. stupně → bojler, přebytek přepadem do kanálu.

## 8. Kvašení, CIP, ochrany

- Kvašení (`proc.fer_step`): Monod, substrát g/L, etanol `0,485 g/g`, teplo 0,6 kJ/g, diacetyl tvorba/redukce podle T. **Chybí CO₂ jako hmotnostní tok** (bilance cukr → etanol + CO₂ + biomasa není uzavřená), tlak, sedimentace kvasnic. Jednotky konzistentní (g/L, h).
- CIP: jen teplota a čas (louh ≥ 75 °C 20 min, kyselina ≤ 60 °C). **Chybí koncentrace, průtok/rychlost, vodivost.** Hodnocení říká „splnění postupu“, ne „sanitární účinnost“.
- Rozvaděč: bez napětí `cab_gate()` vypne čerpadla, míchadla, páru (fyzikálně se zastaví průtoky). Ochrany (interlock) blokují start bez kapaliny v sání / do zavřeného výtlaku; s vypnutou ochranou nastanou následky (nasucho, zavzdušnění, tlaková špička). Poruchy mají fyzikální následek (zavzdušnění → průtok 0, pokles páry → nižší Tst, zanesený chladič → UA×0,45, zadřená klapka).

---

## 9. Největší problémy

| Prio | Kategorie | Oblast | Problém | Důkaz | Dopad | Oprava | Ověření |
|---|---|---|---|---|---|---|---|
| 1 | kritický (receptura) | bilance | Recept 12,5° (700 kg) fyzikálně nedosáhne 40 hl 12,5 °P | `yields()`, autotest: 38,9 hl 11,9 °P | uživatel čeká cíl, který nejde | upravit recept na ≈ 760 kg nebo cíl objemu; kontrola receptu hotová | autotest dosáhne cíle |
| 2 | chyba parametru | scezování | viskozita sladiny × exp(0,025·°P) podhodnocená | `skViscosity` | Δp a vliv °P na lože | koeficient 0,045, překalibrovat `skPerm` | Δp vs měřený tlakoměr |
| 3 | kalibrace | scezování | `skPerm` 1e-11 spíš vysoko (Q_max 150–250 L/min) | lauterlog | lože se utahuje později než v reálu | kalibrovat z provozu | měřit průtok, při kterém Δp prudce roste |
| 4 | zjednodušení | pára | lineární ventil (% = % výkonu) | `_pd` | ohřev při malých otevřeních | charakteristika ventilu + průtok páry (kalibrovatelné) | měření ohřevu při 25/50/75/100 % |
| 5 | zjednodušení | kvašení | chybí CO₂ v bilanci, tlak | `fer_step` | hmotnostní bilance kvašení | přidat CO₂ (0,47 g/g) | součet hmotností |
| 6 | zjednodušení | CIP | bez koncentrace a rychlosti proudění | `cip_step` | nelze hodnotit účinnost | přidat % NaOH/HNO₃, rychlost ≥ 1,5 m/s z hydrauliky | test nesplněné koncentrace |
| 7 | kalibrace | čerpadla | křivky C1–C3 odhad, C4/C5 bez hydrauliky | `PUMPS` | průtoky tras | štítky + měřené průtoky | měřené vs modelové |
| 8 | kalibrace | chmel | faktor 0,44 a α odhad | `spReport` | IBU 29 vs 32 | α z certifikátu, laboratorní IBU | IBU z laboratoře |
| 9 | kalibrace | potrubí | délky × 0,4, vnitřní Ø odhad | `pipeLenScale`, `DN_REAL` | odpor tras | změřit trasy | tlak na výtlaku |
| 10 | zjednodušení | vířivka, DMS, EBC | empirické modely | `sim.gd` | orientační výsledky | označeno jako odhad | laboratoř |

## 10. Plán oprav (cíleně, bez přepisu)

1. **Receptura a cíle** (`sim.gd RECIPES`) – upravit sypání nebo cíle; akceptace: autotest dosáhne cíle ±0,3 °P / ±1 hl. Riziko: malé.
2. **Viskozita + kalibrace lože** (`skViscosity`, `CFG skPerm`) – akceptace: testy scezování v rozsahu, po měření shoda Δp ±20 %. Riziko: střední (změní časy scezování).
3. **Ventil páry** – nelineární charakteristika a strop průtoku páry (konfigurace); akceptace: energie 0 %, test ohřevu při 4 otevřeních. Riziko: malé.
4. **CO₂ ve kvašení** (`proc.gd`) – akceptace: bilance hmotnosti kvašení < 0,5 %. Riziko: malé.
5. **CIP koncentrace a rychlost** (`proc.gd` + hydraulika) – akceptace: nesplněná koncentrace → nesplněno. Riziko: malé.
6. **Kalibrace z měření** – šablona záznamu várky + `kalibrace.json` (loader hotový).

## 11. Závěr

**Top 3 k opravě hned:** (1) recept/cíl objemu vs. výtěžnost, (2) viskozita sladiny a kalibrace propustnosti lože, (3) charakteristika parního ventilu.

**Matematicky ověřené (výpočtem a testem):** bilance extraktu a vody při přenosu, energie ohřevu, odpar z energie, 2. zákon u chladiče, nezávislost na kroku, definice výtěžnosti, determinismus.
**Ověřené jen automatickými testy:** chování lože (Δp, slehávání, kypření), ochrany čerpadel, kvašení, CIP, poruchy.
**Porovnané s provozem:** **nic** – chybí měření.

**Potřebná měření (nejvíc pomůže):**
1. Záznam várky: teploty každých 30 s při ohřevu (objem, tlak páry, % ventilu), časy prodlev, objem a °P předku, sladiny v čase, vyrážky (horký objem + °P).
2. Scezování: průtok C2, Δp pod sítem (pokud je tlakoměr), okamžiky kypření, čas.
3. Štítky čerpadel C1–C3 + změřený průtok při 3 nastaveních FM.
4. Atest sladu (extrakt, vlhkost), rozbor vody, certifikáty α chmele.
5. Chlazení: průtoky a teploty obou stupňů, teplota ledovky v čase.

**Hodnocení realističnosti (1–5):**

| Oblast | ★ | Odůvodnění |
|---|---|---|
| Bilance hmoty a extraktu | 4 | uzavřená a s fyzikálními ztrátami; rozdělení ztrát nekalibrované |
| Pára, ohřev, var | 4 | energeticky konzistentní, správný abs. tlak; lineární ventil, UA odhad |
| Rmutování, dekokce | 3 | dekokce počítaná, enzymatika literární, nekalibrovaná |
| Scezování | 3 | správná fyzika (Darcy, stlačitelnost), ale chyba viskozity a odhad k₀ |
| Čerpadla a potrubí | 3 | průsečík charakteristik, NPSH; křivky a geometrie odhad, C4/C5 zjednodušené |
| Chmel / IBU | 3 | Malowicki, ale empirický faktor a α odhad |
| Chlazení | 4 | ε-NTU, dynamika ledovky; UA odhad |
| Vířivka, DMS, EBC | 2 | empirické |
| Kvašení | 2 | Monod bez CO₂ a tlaku |
| CIP | 2 | jen teplota a čas |
| Rozvaděč a ochrany | 4 | stavy mají fyzikální následky |

Nic z toho není 5 ★ – na 5 ★ je potřeba kalibrace na skutečných měřeních.
