# Parametry modelu – zdroj a nejistota

Typy: MEASURED (změřeno), MANUFACTURER (doklad / údaj provozovatele), LITERATURE, ESTIMATED (odhad), CALIBRATED, UNKNOWN.
Přepsat hodnotu jde souborem `kalibrace.json` ve složce dat aplikace (stejná jako uložená várka), např. `{"rvpUAst": {"value": 7.2, "source": "CALIBRATED"}}`.

| Parametr | Hodnota | Jednotka | Zdroj | Nejistota | Poznámka / jak změřit |
|---|---|---|---|---|---|
| UA1 | 25 | kW/K | ESTIMATED | ±40 % | 1. stupeň deskového chladiče (voda) – změřit vstupy/výstupy a průtoky |
| UA2 | 12 | kW/K | ESTIMATED | ±40 % | 2. stupeň (ledová voda) |
| ambientT | 20 | °C | ESTIMATED | ±5 °C | teplota ve varně |
| betaAct | 4.5 | - | CALIBRATED | 0,1–50 | rychlost štěpení β-amylázy; nastaveno na zdánlivé prokvašení ~76 % u standardní dekokce (typické pro český ležák – upřesnit vlastním rozborem) |
| boilerKW | 650 | kW | MANUFACTURER | jmenovitý | parní kotel 650 kW (údaj provozovatele) – skutečný výkon závisí na tlaku a odběru |
| boilerWaterKg | 1500 | kg | ESTIMATED | 50–20000 | zásoba syté vody v kotli – určuje, jak rychle klesá tlak při přetížení (dh'/dp ≈ 57 kJ/kg·bar); změřit/zjistit ze štítku kotle |
| bore25 | 50 | mm | ESTIMATED | ±10 % | vnitřní průměr trubek DN25 z plánku (Vasil: DN50) |
| bore40 | 50 | mm | ESTIMATED | ±10 % | vnitřní průměr DN40 z plánku (DN50) |
| bore50 | 75 | mm | ESTIMATED | ±10 % | vnitřní průměr DN50 z plánku (silné DN75) |
| chillerKW | 45 | kW | MANUFACTURER | jmenovitý | glykolový agregát 45 kW – skutečný výkon klesá s teplotou okolí |
| cipAcidMin | 0.5 | % | ESTIMATED | 0,5–1 % | minimální koncentrace kyseliny – podle přípravku |
| cipLyeMin | 1 | % NaOH | ESTIMATED | 1–2 % | minimální koncentrace louhu podle provozního předpisu – doplnit podle přípravku |
| coolWaterT | 16 | °C | ESTIMATED | 8–18 °C podle ročního období | teplota vody z řadu |
| cpSteel | 0.5 | kJ/(kg·K) | LITERATURE | 0,46–0,51 | měrná tepelná kapacita austenitické nerezi (AISI 304); jediné místo převodu sim.steelC() |
| hltCap | 12000 | L | MANUFACTURER | ±5 % | bojler 120 hl |
| hltSet | 83 | °C | MANUFACTURER | - | nastavení termostatu 83 °C |
| hltStart | 11000 | L | ESTIMATED | - | počáteční náplň bojleru |
| hltSteel | 600 | kg oceli | ESTIMATED | ±50 % | bojler: dříve natvrdo 300 kJ/K → 600 kg × 0,5 |
| hltT0 | 83 | °C | ESTIMATED | - | počáteční teplota bojleru |
| hltUA | 0.01 | kW/K | ESTIMATED | ±100 % | ztráty izolovaného bojleru – změřit chladnutí přes noc |
| hltUAst | 2 | kW/K | ESTIMATED | ±50 % | ohřev bojleru párou |
| kdAlpha63 | 0.022 | 1/min | LITERATURE | – | inaktivace α-amylázy při 63 °C, Ea 83,7 kJ/mol (Marc et al. 1983, Biotechnol. Bioeng. 25:481) – exponent ze skenu, ověřit |
| kdBeta63 | 0.13 | 1/min | LITERATURE | – | inaktivace β-amylázy při 63 °C, Ea 188 kJ/mol (Marc 1983); 13 % stabilní podíl 40× pomalejší (De Schepper et al. 2022) |
| lvSet | 2 | °C | MANUFACTURER | - | nastavení ledové vody 2 °C |
| lvStart | 0 | L | ESTIMATED | - | počáteční náplň ledovky |
| lvT0 | 2 | °C | ESTIMATED | - | počáteční teplota ledovky |
| lvVol | 10000 | L | MANUFACTURER | ±5 % | ledovka 100 hl |
| malt | 700 | kg | MANUFACTURER | - | sypání podle receptu |
| maltExtract | 80 | % v sušině | LITERATURE | ±2 % | jen záloha pro neznámý slad – extrakt se počítá z tabulky MALTS (atest sladovny) |
| maltMoist | 4.5 | % | LITERATURE | ±1 % | jen záloha – vlhkost se bere z MALTS (atest) |
| maltRate | 40 | kg/min | ESTIMATED | ±30 % | výkon šrotovníku / vystírání |
| mashFilmK | 4.6 | - | CALIBRATED | 0–30 | zhoršení přestupu tepla do hustého rmutu; nastaveno tak, aby plná pánev rmutu hřála ~1 K/min (Weihenstephan, US 10,982,178); var mladiny tím ovlivněn není |
| mill | 1 | stupeň 1–3 | ESTIMATED | - | jemnost šrotu (1 = jemný → propustnost 0,6×, 3 = hrubý → 1,5×) |
| mpCap | 6000 | L | ESTIMATED | ±10 % | mladinová pánev |
| mpDead | 60 | L | ESTIMATED | ±50 % | mrtvý objem |
| mpJacketL | 2500 | L | ESTIMATED | ±20 % | smáčení pláště mladinové pánve |
| mpSteel | 600 | kg oceli | ESTIMATED | ±30 % | mladinová pánev (v plánku nepoužitá) |
| mpUA | 0.3 | kW/K | ESTIMATED | ±50 % | ztráty mladinové pánve |
| mpUAst | 4.5 | kW/K | ESTIMATED | ±40 % | pára → náplň mladinové pánve |
| p1_H0 | 32 | m | ESTIMATED | ±40 % | C1 výtlačná výška při nulovém průtoku – štítek/křivka |
| p1_Qn | 400 | L/min | ESTIMATED | ±40 % | C1 jmenovitý průtok |
| p2_H0 | 22 | m | ESTIMATED | ±40 % | C2 |
| p2_Qn | 150 | L/min | ESTIMATED | ±40 % | C2 |
| p3_H0 | 26 | m | ESTIMATED | ±40 % | C3 |
| p3_Qn | 200 | L/min | ESTIMATED | ±40 % | C3 |
| pipeLenScale | 0.4 | - | ESTIMATED | ±50 % | skutečná délka tras / délka v plánku (100 px = 1 m) – změřit trasy |
| pivLoad | 10 | kW | ESTIMATED | ±50 % | tepelná zátěž okruhu ledové vody |
| plateRefQ | 80 | L/min | ESTIMATED | 10–500 | průtok mladiny, při kterém platí UA1/UA2; prostup roste s průtokem ∝ Q^0,65 (korelace Nu–Re pro deskové výměníky) |
| preboilV | 4430 | L (horká) | STATED | 2000–5000 | plná pánev před varem; nastaveno tak, aby vyrážka byla 40 hl při ~7 %/h odparu (Vasil: 700 kg → 40 hl, 12,5 °P) |
| rvpCap | 5000 | L | MANUFACTURER | ±5 % | nominální objem pánve 50 hl (údaj provozovatele) |
| rvpDead | 20 | L | ESTIMATED | ±50 % | nevyčerpatelný zbytek ve výpusti |
| rvpJacketL | 2200 | L | ESTIMATED | ±20 % | objem náplně, nad kterým je plášť celý smáčený |
| rvpSteel | 450 | kg oceli | ESTIMATED | ±30 % | hmotnost nádoby; kapacita = kg × cpSteel – z výkresu nebo štítku |
| rvpUA | 0.25 | kW/K | ESTIMATED | ±50 % | ztráty pánve do okolí – změřit chladnutí plné pánve bez páry |
| rvpUAst | 6.5 | kW/K | ESTIMATED | ±40 % | přestup pára → náplň; kalibrovat z rychlosti ohřevu (K/min) při známém tlaku páry |
| skArea | 5.3 | m² | MANUFACTURER | ±3 % | plocha falešného dna 5,3 m² (údaj provozovatele) |
| skCap | 5000 | L | ESTIMATED | ±10 % | objem scezovací kádě |
| skChanK | 0.02 | 1/min | ESTIMATED | ×3 | rychlost tvorby kanálků |
| skCompK | 0.05 | 1/min | ESTIMATED | ×3 | rychlost slehávání nad prahem |
| skContactUA | 4 | kW/K | ESTIMATED | ±50 % | přestup náplň ↔ stěna SK |
| skCreepK | 0.0015 | 1/min | ESTIMATED | ×3 | rychlost pomalého sedání lože |
| skDpChannel | 160 | mbar | ESTIMATED | 120–250 | práh vzniku kanálků |
| skDpComp | 30000 | Pa | ESTIMATED | ±50 % | stlačitelnost koláče k = k₀ / (1 + Δp / skDpComp) |
| skDpCompact | 80 | mbar | ESTIMATED | 60–120 | práh rychlého slehávání – kalibrovat z provozu (tlakoměr pod sítem) |
| skMuP | 0.047 | 1/°P | LITERATURE | 0,04–0,055 | μ_sladiny/μ_vody = e^(skMuP·°P); EBC kongresní sladina 8,6 % má ~1,4–1,7 mPa·s při 20 °C (≈1,5× vody) |
| skPerm | 0.000000000015 | m² | CALIBRATED (na referenční scénář, ne na měření) | řád velikosti | 1,5e-11 ≈ 15 darcy; nastaveno tak, aby 40 L/min dalo Δp ~50 mbar; kalibrovat z Δp a průtoku C2 |
| skRetentionLkg | 1 | L/kg sladu | CALIBRATED | 0,8–1,6 | sladina zadržená v mlátě; průmyslové mláto má 20–25 % sušiny ≈ 0,8–1,0 L/kg; 1,0 sedí na údaj Vasila 700 kg → 40 hl / ~12,5 °P. Změřit: objem sladiny, který zůstane po scezení |
| skSteel | 500 | kg oceli | ESTIMATED | ±30 % | scezovací káď včetně falešného dna |
| skSuction | 20000 | Pa | ESTIMATED | ±50 % | největší podtlak pod sítem, který C2 vytvoří – vakuometr pod sítem |
| skTeigK | 0.03 | - | ESTIMATED | ×3 | propustnost těsta vůči mlátu |
| skTeigRho | 350 | kg/m³ | ESTIMATED | ±50 % | hustota (sušina) horního těsta |
| skUA | 0.2 | kW/K | ESTIMATED | ±50 % | ztráty SK |
| spCap | 6000 | L | ESTIMATED | ±10 % | objem spilky |
| spargeEndP | 1.5 | °P | LITERATURE | 1–2 °P | konec vyslazování (poslední podíl) |
| steamBar | 2.5 | bar přetlaku | MANUFACTURER | ±0,3 bar | tlak páry 2,5 bar g; sytostní teplota se počítá z absolutního tlaku (p + 1,013) |
| targetV | 40 | hl | RECEPT | - | cílový objem várky (cíl, ne fyzikální parametr) |
| tbWater | 99.3 | °C | LITERATURE | ±0,3 °C | bod varu vody pro nadmořskou výšku varny (99,3 °C ≈ 200 m n. m.) – upravit podle lokality |
| waterFlow | 250 | L/min | ESTIMATED | ±30 % | průtok čerpadla horké vody C4 do pánve – změřit vodoměrem / časem napouštění |
| wpCap | 5000 | L | ESTIMATED | ±10 % | objem vířivé kádě |
| wpDead | 30 | L | ESTIMATED | ±50 % | kaly + mrtvý objem vířivky |
| wpSteel | 550 | kg oceli | ESTIMATED | ±30 % | vířivá káď |
| wpUA | 0.35 | kW/K | ESTIMATED | ±50 % | ztráty vířivky |

## Čerpadla a potrubí

| Prvek | Hodnota | Zdroj | Poznámka |
|---|---|---|---|
| p1 | H0 32 m, Qn 400 L/min | ESTIMATED | štítek a křivka čerpadla C1 chybí |
| p2 | H0 22 m, Qn 150 L/min | ESTIMATED | štítek a křivka C2 chybí |
| p3 | H0 26 m, Qn 200 L/min | ESTIMATED | štítek a křivka C3 chybí |
| DN | DN25/40 → Ø50 mm, DN50 → Ø75 mm vnitřní | ESTIMATED | vnitřní průměry podle Vasila (silné DN75, ostatní DN50) – ověřit tloušťku stěny |

Bez popisu (ESTIMATED, doplnit): targetEBC, pitchT, targetP, targetIBU, boilMin, water
