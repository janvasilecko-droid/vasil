# Kompletní audit a opravy – Trenažér varny Zajíc (verze 10, 22. 10. 2026)

Vše níže je **skutečně spuštěné** v Godot 4.3 (headless), testy **180 / 180 prošlo**, automatická várka doběhla.
Bod návratu: git commit `verze 9` (`1cdfd6b`) v projektu; předchozí pck v GitHubu `trenazer2d/` (verze 9).

> Upřímně: „skutečně reálný“ = **kalibrovaný na tvé varně**. Opravil jsem všechny **chyby výpočtu**, které šly najít v kódu. Co zbývá, jsou **odhady parametrů** (označené ESTIMATED) – ty z kódu opravit nejde, jen změřit. Nic jsem nepřizpůsoboval tak, aby „vyšel“ cíl.

---

## 1. Opravené chyby výpočtu (s důkazem před / po)

| # | Chyba | Kód před | Kód po | Výsledek před → po | Test |
|---|---|---|---|---|---|
| 1 | **Ocel nádob s c_p = 1,0** místo 0,5 kJ/(kg·K) | `heat()`: `C = cC(v) + steel`; `addTo`: `Cd = cC(dst) + steel`; SK `exchange_bodies(..., c.skSteel, ...)`; vířivka `cC(wv) + c.wpSteel` | jediný převod `steelC(kg) = kg · cpSteel` (0,50, LITERATURE, AISI 304) ve všech 7 místech | 500 L, 60 % páry, 5 min: **ΔT 7,60 → 8,29 K**; efektivní kapacita 2 780 → 2 539 kJ/K (rozdíl proti 0 kg oceli: 482 → 241 kJ/K ✔ = 450 × 0,5 + ztráty) | OCEL ×5 (kapalina, kov, 0 vs 450 kg, bez dvojího započtení, směšování) |
| 2 | Bojler: ocel 300 kJ/K a ztráty 0,01 kW/K natvrdo | `4.19*w + 300.0`, `0.01*(T−amb)` | `steelC(hltSteel)`, `hltUA` v konfiguraci | hodnoty zachovány (600 kg × 0,5 = 300 kJ/K), teď kalibrovatelné | |
| 3 | Ledovka ohřívána od pevných 15 °C | `0.15 * (15.0 - lv.T)` | `0.15 * (ambientT - lv.T)` | při 10 / 30 °C: +0,10 / +0,36 K/h | LEDOVKA |
| 4 | **Viskozita sladiny podhodnocená** | `exp(0.025·P)` (12 °P → ×1,35) | `exp(skMuP·P)`, skMuP = 0,047 (EBC kongresní sladina 8,6 % ≈ 1,5× vody) | 8,6 °P: 1,24× → **1,50×** vody | VISKOZITA |
| 5 | Propustnost lože po opravě viskozity | k₀ 1e-11 | **1,5e-11** – překalibrováno na stejný referenční scénář (40 L/min → Δp ~50 mbar); **CALIBRATED na scénář, ne na měření** | scezování 40 L/min: Δp 55 → 24 mbar ✔, zadřené lože se dá rozkypřit ✔ | AUDIT scezování ×6 |
| 6 | `kalibrace.json` se neuplatnil u uložené várky | jen v `new_state()` | i v `load_game()` + hlášení | | KALIBRACE uložená várka |
| 7 | Kalibrace bez kontroly rozsahů | `c[k] = float(v)` | rozsahy `CALIB_RANGE` pro 60 klíčů, odmítnuté se vypíšou do hlášení | `skArea 0`, `steamBar −3`, text → odmítnuto | KALIBRACE rozsahy |
| 8 | Délky tras, křivky čerpadel, průměry potrubí nešly kalibrovat | konstanty `PUMPS`, `DN_REAL`, `cfg.get("pipeLenScale")` mimo CFG | `pipeLenScale`, `bore25/40/50`, `p1_H0…p3_Qn` v konfiguraci | delší trasy: měnič 24,2 → 26,0 Hz pro 400 L/min | KALIBRACE ×2 |
| 9 | `cfg.maltExtract/maltMoist` nekonzistentní s výpočtem extraktu | pluchy z cfg, extrakt z `MALTS` | obojí z `MALTS` (`grain_dry_insoluble`) | | SLAD |
| 10 | Kvašení bez CO₂ (bilance neuzavřená) | etanol 0,485 g/g, CO₂ nic | Balling: 2,0665 g extraktu → 1 g etanolu + 0,9565 g CO₂ + 0,11 g biomasy | bilance uzavřená na 0,01 g/L | KVAŠENÍ bilance |
| 11 | CIP bez koncentrace | jen T a čas | % NaOH / kyseliny, minimum `cipLyeMin 1,0 %`, `cipAcidMin 0,5 %` (ESTIMATED – podle přípravku), ovládání v panelu | louh 0,5 % při 80 °C 30 min = nesplněno | CIP ×2 |
| 12 | Mrtvé parametry | `rvpPower, rvpMin, mpPower, mpMin, pipeU, hltPower` | odstraněny | | |
| 13 | Chyby v mé tabulce parametrů | mlýn obráceně, targetV „výrobce“, neověřená citace Kunze | opraveno, `PARAMETRY.md` přegenerováno | | |

Kompatibilita: staré uložené várky se načtou; chybějící nové parametry se doplní, staré `skPerm 1e-11` se převede na 1,5e-11 (kvůli nové viskozitě).

---

## 2. Bilance referenční várky (recept 12,5° Zajíc, 700 kg) – po opravách

| | |
|---|---|
| Laboratorní extrakt sladu | 538,50 kg (plzeňský 600 kg → 467,6; carapils 75 → 52,3; mnichovský 25 → 18,6) |
| Vyrážka | 4 171 L horká, 11,9 °P, 498,7 kg extraktu → **výtěžnost varny 71,2 %**, využití lab. extraktu 92,6 % |
| Spilka | 38,9 hl, 11,9 °P, 484,9 kg → **výtěžnost do spilky 69,3 %** |
| Zbytek | sladina v mlátě 18,7 kg, potrubí 15,3, vířivka 12,7, pánev 2,5, škrob v loži 4,5, kanál 0 |
| Bilance extraktu | 538,498 vs 538,503 kg (0,005 kg) |
| Energie ohřevu | 1. zákon 0,0 %; var: odpar = přebytek / 2 257 kJ/kg (chyba < 3 %) |

**Recept 12,5° nedosáhne 40 hl × 12,5 °P** (potřeba 525 kg extraktu = 97,5 % potenciálu). Na 40 hl je potřeba ≈ 760 kg sladu. **Recept jsem neměnil** – je to tvoje rozhodnutí (víc sladu, nebo cíl ~39 hl / 12 °P).

---

## 3. Co je ověřeno a jak

- **Matematicky (výpočtem + testem):** bilance vody a extraktu, energie ohřevu a varu, ocel, směšování, 2. zákon u chladiče, kvašení (Balling), definice výtěžnosti, determinismus, nezávislost na kroku.
- **Jen automatickými testy (vnitřní konzistence):** lože (Δp, slehávání, kypření), ochrany čerpadel, CIP, poruchy.
- **Proti provozním měřením: nic** – žádná měření zatím nemám.

---

## 4. Co zbývá – odhady, které opraví jen měření

| Parametr | Teď | Co změřit |
|---|---|---|
| `rvpUAst` (přestup páry) 6,5 kW/K | ESTIMATED | ohřev pánve: objem, tlak páry, % ventilu, teplota každých 30 s |
| charakteristika parního ventilu | lineární | totéž při 25 / 50 / 75 / 100 % |
| `rvpUA`, `hltUA` (ztráty) | ESTIMATED | chladnutí plné pánve / bojleru bez páry |
| `skPerm`, `skSuction`, `skDpCompact/Channel` | ESTIMATED / CALIBRATED na scénář | Δp pod sítem (vakuometr) a průtok C2 v čase, okamžiky kypření |
| `skRetentionLkg` | ESTIMATED | objem sladiny zbylé v mlátě |
| křivky C1–C3, `pipeLenScale`, průměry | ESTIMATED | štítky čerpadel, průtok při 3 nastaveních FM, délky tras |
| `UA1`, `UA2` (chladič; nezávislé na průtoku) | ESTIMATED | teploty a průtoky obou stran při 2 průtocích mladiny |
| α chmele, faktor IBU 0,44 | ESTIMATED | certifikáty α, laboratorní IBU |
| extrakty sladů | atest? | atest sladovny (extrakt, vlhkost) |
| voda (alkalita 100, Ca 50, Mg 10) | ESTIMATED | rozbor vody |
| kinetika kvašení | ESTIMATED | denní °P a teplota ve spilce |
| CIP minima | ESTIMATED | předpis výrobce přípravku |

Hodnoty vložíš do `kalibrace.json` (stejná složka jako uložená várka, `%APPDATA%\Godot\app_userdata\Trenažér varny Zajíc\`), program je zkontroluje a použije – i pro rozjetou várku.

---

## 5. Hodnocení po opravách (1–5 ★)

| Oblast | ★ | Proč ne 5 |
|---|---|---|
| Bilance hmoty a extraktu | 4 | rozdělení ztrát (retence v mlátě) nezměřené |
| Pára, ohřev, var | 4 | UA a ventil odhad |
| Rmutování a dekokce | 3 | enzymatika literární, nekalibrovaná |
| Scezování | 3 | správná fyzika, propustnost jen na referenční scénář |
| Čerpadla a potrubí | 3 | křivky a geometrie odhad (teď kalibrovatelné) |
| Chlazení | 4 | UA odhad, nezávislé na průtoku |
| Chmel / IBU | 3 | α a faktor odhad |
| Kvašení | 3 | bilance uzavřená (Balling), kinetika odhad, bez tlaku |
| CIP | 3 | T, čas, koncentrace; bez rychlosti proudění a vodivosti |
| Vířivka, DMS, EBC | 2 | empirické |
| Rozvaděč a ochrany | 4 | stavy s fyzikálními následky |

---

## 6. Jak spustit a jak se vrátit

- Aktualizace: v aplikaci **⟳ Aktualizovat** (verze 10). Testy: `Trenazer varny.exe -- --tests`.
- Návrat: v `%APPDATA%\Godot\app_userdata\Trenažér varny Zajíc\` smaž `update2d.pck` a `update2d_ver.json` → poběží vestavěná verze 1. Na přání nahraju libovolnou starší verzi (git v projektu má všechny).
